// configUploads.js
const path = require("path");

const UPLOADS_DIR = path.join(__dirname, "uploads");

module.exports = { UPLOADS_DIR };
